# ***[gvs]***
daemon_list = []
from ..VoiceTalk_library.voicetalk import VoiceTalk
voicetalk = VoiceTalk()
# daemon_list.append(voicetalk)
# Language Set = {'en-US', 'cmn-Hant-TW'}
Language = 'en-US'


# ***[gvsro]***
[0,1,4]