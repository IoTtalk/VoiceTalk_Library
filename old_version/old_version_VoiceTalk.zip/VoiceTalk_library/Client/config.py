TokenTablePath = '../DB/enUS/TokenTable.csv'
RuleTablePath = '../DB/RuleTable.csv'
VoiceTalkTablePath = '../DB/VoiceTalkTable.csv'
TokenListPath = '../DB/TokenList.txt'

Dia_API_key = '../DB/Dialogflow_test1.json'
Dia_project_id = "test1-cidr"
STT_client_file = "../DB/stt-test2_20230831.json"

Port = 10826